import serial.tools.list_ports
import serial
    
class USB2SPIDriver:

    def __init__(self, port="COM1"):
        self.ser = serial.Serial(port, 231297, timeout=1)
        for c in [0x55, 0x00, 0xff, 0xaa]:
            r = self.__echo(c)
            if r != c:
                print('Echo test failed - not attached?')
                print('Expected %r but received %r' % (c, r))
                raise IOError
        self.getstatus()
        
    def query_firmrev(self):
        rev = []
        self.ser.write(bytearray([0]))
        rev = self.ser.readline(-1)
        self.ser.read(1)
        return (rev.decode())
    
    def __echo(self, c):
        self.ser.write(bytearray([101,c]))
        r = self.ser.read(1)
        return r[0]
    
    def reset(self):
        self.ser.write(b'@')
        r = self.ser.read(1)
        return r

    def detach(self):
        self.ser.write(b'x')

    def sel(self):
        self.ser.write(bytearray([6]))

    def unsel(self):
        self.ser.write(bytearray([12]))

    def read(self, l):
        bb2 = bytearray([0x33, l])
        self.ser.write(bb2)
        r = self.ser.read(l)
        return r

    def write(self, bb):
        bb.insert(0,3)
        sub = bytearray(bb)
        self.ser.write(sub)

    def writeread(self, bb):
        #print("Writing "+str(len(bb))+" bytes")
        bb.insert(0,len(bb))
        bb.insert(0,54)
        bb1 = bytearray(bb)
        self.ser.write(bb1)
        #print(bb1)
        #print("Reading "+str(len(bb)-2)+" bytes")
        r = self.ser.read(len(bb)-2)
        #print(r)
        return r

    def seta(self, v):
        self.ser.write(bytearray([0x3c, v]))

    def setb(self, v):
        self.ser.write(bytearray([0x63, v]))

    def setmode(self, m):
        self.mode = m
        self.ser.write(bytearray([0x66,self.mode,self.shift_mode,self.speed]))
        
    def setspeed(self, s):
        self.speed = s
        self.ser.write(bytearray([0x66,self.mode,self.shift_mode,self.speed]))
        
    def getstatus(self):
        self.ser.write(b'\x6c')
        r = list(self.ser.read(3))
        self.mode           = int(r[0])
        self.shift_mode     = int(r[1])
        self.speed          = int(r[2])
    
    def close(self):
        self.ser.close()